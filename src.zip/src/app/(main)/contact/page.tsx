import Contact from "@/components/customer-page/contact/contact";

const ContactPage = () => {
  return <Contact />;
};
export default ContactPage;
