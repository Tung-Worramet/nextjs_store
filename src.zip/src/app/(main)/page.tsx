import { Button } from "@/components/ui/button";

const HomePage = () => {
  return (
    <div>
      <Button>Click</Button>
    </div>
  );
};
export default HomePage;
